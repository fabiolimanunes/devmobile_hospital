package com.fabionunes.hospital;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;


public class Resultado extends Activity{
    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__hosp);

        Intent intentrecebedora = getIntent();

        Bundle parametros = intentrecebedora.getExtras();

        if(parametros != null){
            String nome = parametros.getString("chave_nome");
            double pressao = parametros.getDouble("chave_pressao");


        }

    }

    }

