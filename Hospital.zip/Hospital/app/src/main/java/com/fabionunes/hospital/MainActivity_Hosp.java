package com.fabionunes.hospital;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity_Hosp extends AppCompatActivity {
    private EditText edt_nome;
    private EditText edt_nleito;
    private EditText edt_pressao;
    private EditText edt_bat_card;
    private EditText edt_temperatura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__hosp);

        edt_nome = (EditText) findViewById(R.id.edt_nome);
        edt_pressao = (EditText) findViewById(R.id.edt_pressao);
    }

    public void onClickIncluir (View view){
        String nome = edt_nome.getText().toString();
        double pressao = Double.parseDouble(edt_pressao.getText().toString());

        Intent  intentenviadora = new Intent(getApplicationContext(), Resultado.class);
        Bundle parametros = new Bundle();

        parametros.putString("chave_nome",nome);
        parametros.putDouble("chave_pressao",pressao);

        intentenviadora.putExtras(parametros);

        startActivity(intentenviadora);
    }

}
